/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _TOOLS_IO_H
#define _TOOLS_IO_H

#endif
