/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _TOOLS_DEBUGFS_H
#define _TOOLS_DEBUGFS_H

#endif
