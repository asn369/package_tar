/* SPDX-License-Identifier: GPL-2.0 */
#ifndef TESTS_H
#define TESTS_H

int test_cpumap(int argc, char **argv);
int test_threadmap(int argc, char **argv);
int test_evlist(int argc, char **argv);
int test_evsel(int argc, char **argv);

#endif /* TESTS_H */
